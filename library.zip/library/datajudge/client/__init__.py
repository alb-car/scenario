from datajudge.client.client import Client

__all__ = ["Client"]
