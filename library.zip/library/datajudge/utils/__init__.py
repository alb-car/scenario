from datajudge.utils import config

__all__ = ["config"]
